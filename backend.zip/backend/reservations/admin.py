from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Reservation


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "user",
        "locker",
        "status",
        "reserved_until",
        "created_at",
        "released_at",
    )
    list_filter = ("status", "created_at")
    search_fields = ("user__username", "locker__locker_number")