from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Locker
from .serializers import LockerSerializer
from .permissions import IsAdminOrReadOnly

class LockerViewSet(viewsets.ModelViewSet):
    queryset = Locker.objects.all().order_by("locker_number")
    serializer_class = LockerSerializer
    permission_classes = [IsAuthenticated, IsAdminOrReadOnly]