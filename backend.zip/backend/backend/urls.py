from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse

def home(request):
    return HttpResponse("Backend Running 🚀")

urlpatterns = [
    path('', home),
    path('admin/', admin.site.urls),
    path('api/auth/', include('accounts.urls')),

    # Auth
    path('api/auth/', include('users.urls')),

    # Lockers & Reservations
    path('api/', include('lockers.urls')),
    path('api/', include('reservations.urls')),
]